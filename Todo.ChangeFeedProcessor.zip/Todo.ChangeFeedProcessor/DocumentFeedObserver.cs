﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.ChangeFeedProcessor;

namespace Todo.ChangeFeedProcessor
{
    /// <summary>
    /// This class implements the IChangeFeedObserver interface and is used to observe 
    /// changes on change feed. ChangeFeedEventHost will create as many instances of 
    /// this class as needed. 
    /// </summary>
    public class DocumentFeedObserver : IChangeFeedObserver
    {
        private static int _totalDocs;

        public Task OpenAsync(ChangeFeedObserverContext context)
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine($"Observer opened for partition key range: {context.PartitionKeyRangeId}");

            return Task.CompletedTask;
        }

        public Task ProcessChangesAsync(ChangeFeedObserverContext context, IReadOnlyList<Document> docs)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Change feed: PartitionId {context.PartitionKeyRangeId} total {Interlocked.Add(ref _totalDocs, docs.Count)} doc(s)");

            foreach (var doc in docs)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(doc.Id);
            }

            return Task.CompletedTask;
        }

        public Task CloseAsync(ChangeFeedObserverContext context, ChangeFeedObserverCloseReason reason)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"Observer closed, {context.PartitionKeyRangeId}");
            Console.WriteLine($"Reason for shutdown, {reason}");

            return Task.CompletedTask;
        }
    }
}
