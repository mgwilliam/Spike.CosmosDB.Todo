﻿using System;
using Microsoft.Azure.Documents.ChangeFeedProcessor;

namespace Todo.ChangeFeedProcessor
{
    /// <summary>
    /// Factory class to create instance of document feed observer. 
    /// </summary>
    public class DocumentFeedObserverFactory : IChangeFeedObserverFactory
    {
        public IChangeFeedObserver CreateObserver()
        {
            var newObserver = new DocumentFeedObserver();
            return newObserver;
        }
    }
}
