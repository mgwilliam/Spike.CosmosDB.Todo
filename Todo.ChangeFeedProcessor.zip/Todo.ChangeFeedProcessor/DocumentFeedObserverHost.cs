﻿using System;
using System.Threading.Tasks;
using Microsoft.Azure.Documents.ChangeFeedProcessor;
using Microsoft.Azure.Documents.Client;

namespace Todo.ChangeFeedProcessor
{
    public class DocumentFeedObserverHost
    {
        private ChangeFeedEventHost _host;

        public async Task RunChangeFeedHostAsync(DocumentCollectionInfo sourceCollectionInfo)
        {
            var leaseCollectionLocation = new DocumentCollectionInfo
            {
                Uri = sourceCollectionInfo.Uri,
                MasterKey = sourceCollectionInfo.MasterKey,
                DatabaseName = sourceCollectionInfo.DatabaseName,
                CollectionName = "leases"
            };

            var feedOptions = new ChangeFeedOptions
            {
                StartFromBeginning = true
            };

            var feedHostOptions = new ChangeFeedHostOptions
            {
                LeaseRenewInterval = TimeSpan.FromSeconds(15),
                FeedPollDelay = TimeSpan.FromMilliseconds(250d)
            };

            var docObserverFactory = new DocumentFeedObserverFactory();

            var hostName = Guid.NewGuid().ToString();

            _host = new ChangeFeedEventHost(hostName, sourceCollectionInfo, leaseCollectionLocation, feedOptions, feedHostOptions);

            await _host.RegisterObserverFactoryAsync(docObserverFactory);
        }

        public async Task StopHostAsync()
        {
            await _host.UnregisterObserversAsync();
        }
    }
}
