﻿using System;
using System.Threading.Tasks;
using Microsoft.Azure.Documents.ChangeFeedProcessor;

namespace Todo.ChangeFeedProcessor
{
    public class Program
    {
        private readonly string _monitoredUri = "<insert URI here>";
        private readonly string _monitoredSecretKey = "<insert key here>";
        private readonly string _monitoredDbName = "todos";
        private readonly string _monitoredCollectionName = "events";

        public static void Main(string[] args)
        {
            Console.WriteLine($"Change Feed Processor client started at: {DateTime.Now.ToShortTimeString()}");

            new Program().MainAsync().Wait();
        }

        private async Task MainAsync()
        {
            var sourceCollectionInfo = new DocumentCollectionInfo
            {
                Uri = new Uri(_monitoredUri),
                MasterKey = _monitoredSecretKey,
                DatabaseName = _monitoredDbName,
                CollectionName = _monitoredCollectionName
            };

            var host = new DocumentFeedObserverHost();

            await host.RunChangeFeedHostAsync(sourceCollectionInfo);

            Console.WriteLine("Running... Press enter to stop");
            Console.ReadLine();

            await host.StopHostAsync();
        }
    }
}
